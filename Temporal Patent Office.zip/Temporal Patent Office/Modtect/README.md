# Modtect
Detect possible actual value in a Modulus based system

Theres this catch 22 to divination where in order for Mathematics to be Divine, there has to be a reversing directive, this should allow that where Modulus is often used as a limiter.

Usage: Python3 antimod.py multiplier leftover limiter

![Screenshot 2023-09-26 035652](https://github.com/777388/Modtect/assets/96343159/de16025c-cc38-43a4-a41e-0d42d6d886b1)


#Update

Put in absolute values and accounted for divining process.

Example given provides succession diagonally in last number
![image](https://github.com/777388/Modtect/assets/96343159/1bc87810-051c-440f-967b-e8238a5e763c)

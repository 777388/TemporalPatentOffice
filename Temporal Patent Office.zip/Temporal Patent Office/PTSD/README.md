# PTSD
Backtrack to previous positions with the first backtracking to the last, modifying and consolidating until unified as 1 letter. Past a certain point it's shepherds speech

Also does statistics, be sure to alter the edit axis if you plan on using it for art, there are 2 statistics plottings, the second one is best modified at scale

![image](https://github.com/777388/PTSD/assets/96343159/118d423f-a5eb-41cf-ab42-bb451a43190b)


![Screenshot 2023-10-16 104016](https://github.com/777388/PTSD/assets/96343159/998f6ce1-6aa1-4ead-96fb-c8ceed626e78)

![Screenshot 2023-10-16 105654](https://github.com/777388/PTSD/assets/96343159/a7c87876-113c-4092-969f-2d6cb28ca86b)


https://www.youtube.com/watch?v=giaZnIr-faM

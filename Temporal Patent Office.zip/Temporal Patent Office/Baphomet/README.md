# Baphomet
Entrance, Escalate, Assimilate, Individualize, Exit, Calm, Solve, Coagula


ENTRANCE:

usage: python3 8and6.py 258

or any number of your choosing, I just went with 258 because its 6+(6^2)+(6^3) 

ESCALATE:

While 8and6.py will be useful in checking for patterns of master numbers regarding the values up to your choosing, 9.py is useful for knowing the values of your choosing.

usage: Python3 9.py 258

ASSIMILATE:

with 49.py you'll be able to use a string as such 

usage:python3 49.py "my dick"

INDIVIDUALIZE:

with Divine.py you'll be able to convert the string back to the number it was equated out to be, which is important in divine numbers according to a book I found on Conjuring https://archive.org/details/magiciansownbook00arno/page/202/mode/2up?view=theater  uses strings instead of numbers

usage: python3 Divine.py "conjure"

EXIT:

8&6B49.py and 5.py require no explanation.

CALM:

https://www.youtube.com/watch?v=eGT8khAoGx0

Its pretty interesting how x*reversenum(x)/x = x+reversenum(x)-x. Likewise reversenum(x)*x/reversenum(x) = reversenum(x)+x-reversenum(x)

12 * 21 / 12 = 12 + 21 -12

SOLVE:

With Baphomet.py you'll be able to convert a string to a number, and then it will put together a matrix map of equations leading up to that number. While the final series on 6 in not echoing back whether it is for self, consciousness, time or space, through the repeated usage of the backwards ae, ɘa.

COAGULA:

usage: python3 Baphomet.py Baphomet


Run question.py, copy down what it spits out, and paste it into Baphomet.py

I got this PMC number https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8844676/ The Government Willingly admits that there are anti antibodies that cause the vaccine to kill people.

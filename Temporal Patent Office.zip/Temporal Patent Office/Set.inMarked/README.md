# Set.inMarked
According to Real Mathematics (The departure of Analysis) if multiple sets are comprised of the same letters, no matter how many times each used, they  are the same set

When looking into a new field, or doing a check on a phrase or important factor, please check the reality against previous matters using this program

usage: python3 real.py "your matter of importance"

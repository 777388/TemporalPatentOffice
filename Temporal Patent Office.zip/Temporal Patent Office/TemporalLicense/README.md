# TemporalLicense
Divination, Random Chance, Xor and Timing used for licensing

This allows multiple licenses to be printed and mapped out to allow created works to be in a constant state of flux, meaning each respective viewer of creations and identities will have their own version determined by divination, random chance, xor, timing and their own interactions. If you find yourself stuck with anothers creation all you simply need to do is create another thing, which could be as simple as a rhyme or a smiley face drawn in inspiration of the work, and it will create a cloned pair license of the creation, as each license is in a cloned pairing state.

Usage python3 TemporalIdentity.py "name of work"

# TheTemptress
Love can be explained in Math.

After a few type errors until we Overflowed, 175 times we've found "Sure" she's the one

![image](https://github.com/777388/TheTemptress/assets/96343159/9753e16f-02e3-45ab-93f0-b259f31fb37b)
